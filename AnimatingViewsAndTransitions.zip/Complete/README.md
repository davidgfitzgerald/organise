# Completed project: Animating views and transitions

Explore the completed project for the [Animating views and transitions](https://developer.apple.com/tutorials/swiftui/animating-views-and-transitions) tutorial.
