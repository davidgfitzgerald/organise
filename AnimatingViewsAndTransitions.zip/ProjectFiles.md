# Project files: Animating views and transitions

To follow the [Animating Views and Transitions](https://developer.apple.com/tutorials/swiftui/animating-views-and-transitions) tutorial, start with your completed project from the previous tutorial, or open the Xcode project in the **StartingPoint** folder. When prompted by the tutorial, you'll need the JSON in the **Resources** folder. To explore on your own, open the Xcode project in the **Complete** folder and browse the project's code.

- Note: To preview and interact with views from the canvas in Xcode ensure your Mac is running macOS Sonoma or later.
